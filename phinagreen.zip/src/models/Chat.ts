export interface Chat {
  message: string;
  bot?: boolean;
}